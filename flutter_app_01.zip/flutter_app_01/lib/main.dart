import 'package:flutter/material.dart';
// import 'package:flutter_app_01/TelaNavegacao.dart';

void main(){
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AppHeitor',

      // TEMAS
      theme: ThemeData(
        primaryColor: Colors.green.shade900,
        backgroundColor: Colors.grey.shade100,

        textTheme: TextTheme(
          headline1: TextStyle(
            fontSize: 24,
            color: Colors.grey.shade900,
          ),

          //LabelStyle
          headline2: TextStyle(
            fontSize: 20,
            color: Colors.green.shade900,
          ),

          //HintStyle
          headline3: TextStyle(
            fontSize: 20,
            color: Colors.grey.shade300,
          ),

        ),

        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            primary: Colors.green.shade900,
            textStyle: TextStyle(
              fontSize: 24,
            ),
          ),
        ),
      ),
      initialRoute: 'Tela1',
      routes: {
        'Tela1': (context) => TelaPrincipal(),
        'Tela2': (context) => TelaMenu(),
        'Tela3': (context) => TelaCompras(),
        'Tela4': (context) => TelaMapa(),
        'Tela5': (context) => TelaFavoritos(),
        'Tela6': (context) => TelaUsuario(),
        'Tela7': (context) => TelaSobre(),
      },
    )
  );
}

// TELA PRINCIPAL (STATEFUL)
class TelaPrincipal extends StatefulWidget {
  const TelaPrincipal({ Key? key }) : super(key: key);
  @override
  TelaLogin createState() => TelaLogin();
}

class TelaLogin extends State<TelaPrincipal> {
  var txtCPF = TextEditingController();
  var txtSenha = TextEditingController();
  var formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).backgroundColor,
      body: Container(
        padding: EdgeInsets.all(30),
        child: Form(
          key: formKey,
          child: Column(
            children: [
              Icon(
                Icons.account_circle, 
                size: 120, 
                color: Theme.of(context).primaryColor,
              ),
              campoCPF('CPF', txtCPF),
              campoSenha('Senha', txtSenha),
              botao('Entrar'),
            ],
          ),
        ),
      ),
    );
  }
  // CAMPO DO CPF
  Widget campoCPF(rotulo, variavel){
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: TextFormField(
        style: Theme.of(context).textTheme.headline1,
        controller: variavel,
        decoration: InputDecoration(
          labelText: rotulo,
          labelStyle: Theme.of(context).textTheme.headline2,
          hintText: 'Digite seu CPF',
          hintStyle: Theme.of(context).textTheme.headline3,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        // VALIDADOR CPF
        validator: (value){
          if (value == ''){
            return 'CPF obrigatório';
          }
          else{
            return null;
          }
        },
      ),
    );
  }
  // CAMPO DE TEXTO PARA ENTRADA DO SENHA
  Widget campoSenha(rotulo, variavel){
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: TextFormField(
        style: Theme.of(context).textTheme.headline1,
        controller: variavel,
        decoration: InputDecoration(
          labelText: rotulo,
          labelStyle: Theme.of(context).textTheme.headline2,
          hintText: 'Digite sua senha',
          hintStyle: Theme.of(context).textTheme.headline3,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),

        // VALIDADOR SENHA
        validator: (value){
          if (value == ''){
            return 'Senha obrigatória';
          }else{
            return null;
          }
        },
      ),
    );
  }
  // BOTAO
  Widget botao(rotulo){
    return Container(
      width: 200,
      height: 70,
      padding: EdgeInsets.symmetric(vertical: 12),
      child: ElevatedButton(
        child: Text(rotulo),
        onPressed: (){
          if (formKey.currentState!.validate()){  
              Navigator.pushNamed(context, 'Tela2');
          }
        },
      ),
    );
  }
}

// TELA MENU
class TelaMenu extends StatelessWidget {
  const TelaMenu({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('MENU')),
      body: SingleChildScrollView(
        child: Center(
            child: Column(
              children: [
                Container(
                  width: 450,
                  height: 120,
                  padding: EdgeInsets.all(25),
                  child: ElevatedButton(
                    child: Text('COMPRAS'),
                    onPressed: (){  
                      Navigator.pushNamed(context, 'Tela3');
                    }
                  ),  
                ),
                Container(
                  width: 450,
                  height: 120,
                  padding: EdgeInsets.all(25),
                  child: ElevatedButton(
                    child: Text('MAPA'),
                    onPressed: (){  
                      Navigator.pushNamed(context, 'Tela4');
                    }
                  ),  
                ),
                Container(
                  width: 450,
                  height: 120,
                  padding: EdgeInsets.all(25),
                  child: ElevatedButton(
                    child: Text('FAVORITOS'),
                    onPressed: (){  
                      Navigator.pushNamed(context, 'Tela5');
                    }
                  ),  
                ),
                Container(
                  width: 450,
                  height: 120,
                  padding: EdgeInsets.all(25),
                  child: ElevatedButton(
                    child: Text('USUÁRIO'),
                    onPressed: (){  
                      Navigator.pushNamed(context, 'Tela6');
                    }
                  ),  
                ),
                Container(
                  width: 450,
                  height: 120,
                  padding: EdgeInsets.all(25),
                  child: ElevatedButton(
                    child: Text('SOBRE'),
                    onPressed: (){  
                      Navigator.pushNamed(context, 'Tela7');
                    }
                  ),  
                ),
              ],
            ),
          ),
        ),
    );
  }
}

//TELA COMPRAS
class TelaCompras extends StatefulWidget {
  const TelaCompras({Key? key}) : super(key: key);
  @override
  _TelaCompras createState() => _TelaCompras();
}

class _TelaCompras extends State<TelaCompras> {
  var lista = [];
  @override
  void initState() {
    lista.add("Queijo");
    lista.add("Doce de Leite");
    lista.add("Bolacha");
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('COMPRAS'),
      ),
      body: Container(
        padding: EdgeInsets.all(30),
        child: ListView.builder(
          itemCount: lista.length,
          itemBuilder: (context, index) {
            return Card(
              color: Colors.grey.shade100,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: ListTile(
                title: Text(
                  lista[index],
                  style: TextStyle(fontSize: 20),
                ),
                trailing: IconButton(
                  icon: Icon(Icons.delete_outline),
                  onPressed: () {
                    setState(() {
                      lista.removeAt(index);
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text('Item Removido'),
                        duration: Duration(seconds: 2),
                      ));
                    });
                  },
                ),
              ),
            );
          },
        ),
      ),

      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.shopping_cart),
        onPressed: () async {
          await showDialog(
              context: context,
              builder: (context) {
                return AlertDialog(
                  title: Text(
                    'Operação não implementada',
                    style: TextStyle(fontSize: 16),
                  ),
                  actions: [
                    TextButton(
                      child: Text('ok'),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                  ],
                );
              }
            );
        },
      ),
    );
  }
}

// TELA MAPA
class TelaMapa extends StatelessWidget {
  const TelaMapa({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('MAPA')),
      body: Container(
        width: double.infinity,  
        height: double.infinity,
        child: Image.asset('lib/imagens/mapa.jpg')
      ),
    );
  }
}

//TELA FAVORITOS
class TelaFavoritos extends StatefulWidget {
  const TelaFavoritos({Key? key}) : super(key: key);
  @override
  _TelaFavoritos createState() => _TelaFavoritos();
}

class _TelaFavoritos extends State<TelaFavoritos> {
  var lista = [];
  @override
  void initState() {
    lista.add("Queijo");
    lista.add("Doce de Leite");
    lista.add("Bolacha");
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('COMPRAS'),
      ),
      body: Container(
        padding: EdgeInsets.all(30),
        child: ListView.builder(
          itemCount: lista.length,
          itemBuilder: (context, index) {
            return Card(
              color: Colors.grey.shade100,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: ListTile(
                title: Text(
                  lista[index],
                  style: TextStyle(fontSize: 20),
                ),
                subtitle: Text('Tenda do Heitor'),
                trailing: IconButton(
                  icon: Icon(Icons.favorite),
                  onPressed: () {
                    setState(() {
                      lista.removeAt(index);
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text('Item Removido'),
                        duration: Duration(seconds: 2),
                      ));
                    });
                  },
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

// TELA USUÁRIO
class TelaUsuario extends StatelessWidget {
  const TelaUsuario({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('EDITAR PERFIL')),
      backgroundColor: Theme.of(context).backgroundColor,
      body: Center(
        child: Column(
            children: [
              Container(
                width: double.infinity,
                color: Colors.grey.shade400,
                child:
                  Icon(
                    Icons.account_circle, 
                    size: 150, 
                    color: Theme.of(context).primaryColor,
                  ),
              ),
              Container(
                width: double.infinity,
                color: Colors.grey.shade600,
                child: Center(
                  child: Text('Toque para mudar', style: TextStyle(color: Colors.white),),
                  ),
              ),
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(15),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.grey.shade300,
                    width: 1,
                  ),
                ),
                child: Text('Informações pessoais',
                  style: TextStyle(
                    color: Colors.grey.shade700,
                    fontSize: 20
                  ),
                ),
              ),
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(15),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.grey.shade300,
                    width: 1,
                  ),
                ),
                child: Text('Informações da conta',
                  style: TextStyle(
                    color: Colors.grey.shade700,
                    fontSize: 20
                  ),
                ),
              ),
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(15),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.grey.shade300,
                    width: 1,
                  ),
                ),
                child: Text('Configurações',
                  style: TextStyle(
                    color: Colors.grey.shade700,
                    fontSize: 20
                  ),
                ),
              ),

              Container(
                width: double.infinity,
                padding: EdgeInsets.all(15),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.grey.shade300,
                    width: 1,
                  ),
                ),
                child: TextButton(
                  child: Text('Notificações',
                    style: TextStyle(
                      color: Colors.grey.shade700,
                      fontSize: 20
                    ),
                  ),
                  onPressed: (){  
                    showDialog(
                      context: context,
                      builder: (BuildContext context){
                        return AlertDialog(
                          title: Text('Erro'),
                          content: Text('Operação não implementada'),
                          actions: [
                            TextButton(
                              child: Text('fechar'),
                              onPressed: (){
                                Navigator.of(context).pop();
                              },
                            ),
                          ],
                        );
                      }
                    );
                  }
                ),
              ),
            ]
          )
        ),
      );
  }
}

// TELA SOBRE
class TelaSobre extends StatelessWidget {
  const TelaSobre({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('SOBRE')),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(20, 20, 20, 20),
                padding: EdgeInsets.all(30),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.grey.shade700,
                    width: 1,
                  ),
                color: Colors.green.shade900,
                ),
                width: MediaQuery.of(context).size.width * 0.90,
                child: Column(
                  children: [
                    Text('TEMA\n',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold
                      )
                    ),
                    Text('A introdução da tecnologia de venda por aplicativo e controle de estoque para impulsionar  microempreendedores',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                      )
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.fromLTRB(20, 20, 20, 20),
                padding: EdgeInsets.all(30),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.grey.shade700,
                    width: 1,
                  ),
                color: Colors.green.shade900,
                ),
                width: MediaQuery.of(context).size.width * 0.90,
                child: Column(
                  children: [
                    Text('OBJETIVO\n',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      )
                    ),
                    Text('- OBJETIVO GERAL\n',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                      )
                    ),
                    Text('Desenvolver um protótipo de software para controle de estoque e venda de mercadorias, que faz uso da posição geográfica para conectar usuários vendedores e clientes.\n',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                      )
                    ),
                    Text('- OBJETIVO ESPECÍFICO\n',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                      )
                    ),
                    Text('Aplicativo multiplataforma (Android e IOS);\nPermite transações financeira no Aplicativo;\nDedicado para vendedores moveis.',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                      )
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.fromLTRB(20, 20, 20, 20),
                padding: EdgeInsets.all(30),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.grey.shade700,
                    width: 1,
                  ),
                color: Colors.green.shade900,
                ),
                width: MediaQuery.of(context).size.width * 0.90,
                child: Column(
                  children: [
                    Text('DESENVOLVEDOR\n',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      )
                    ),
                    Text('Heitor Santos Afonso\n',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                      )
                    ),
                    Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                        color: Colors.grey.shade700,
                        width: 1,
                        ),
                      ),
                      child: Image.asset('lib/imagens/heitor.jpeg')
                    ),
                  ],
                ),
              )
            ]
          )
        )
      )
    );
  }
}